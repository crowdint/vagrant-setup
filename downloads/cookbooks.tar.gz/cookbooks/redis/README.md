# Redis recipe

This cookbook will serve as a starting point for a Redis 2:1.2.0-1 installation
Supported systems: *Ubuntu Linux Lucid 64bits.*

## Connect

- host: 33.33.33.10
- port: 5432

## Warning

*Disclaimer:* This recipe should never be used on production environments as
it's insecure on purpose.