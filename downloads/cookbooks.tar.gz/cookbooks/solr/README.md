# Solr recipe

This cookbook will install and start solr both for development and test mode.
Supported systems: *Ubuntu Linux Lucid 64bits.*

## Connect

- port: 8983 - Development
- port: 8984 - Test

## Warning

*Disclaimer:* This recipe should never be used on production environments as
it's insecure on purpose.