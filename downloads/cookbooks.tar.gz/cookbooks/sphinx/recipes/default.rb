package "sphinxsearch" do
  action :install
end