package "ruby1.8 ruby1.8-dev irb rdoc ri" do
  action :install
end

gem_package "testbot" do
  action :install
end
