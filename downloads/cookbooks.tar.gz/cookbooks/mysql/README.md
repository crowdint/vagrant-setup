# MySQL recipe

This cookbook will serve as a starting point for a MySQL installation.
Supported systems: *Ubuntu Linux Lucid 64bits.*

## Connect

- host: 33.33.33.10
- user: root (no password)
- port: 5432

## Warning

*Disclaimer:* This recipe should never be used on production environments as
it's insecure on purpose.