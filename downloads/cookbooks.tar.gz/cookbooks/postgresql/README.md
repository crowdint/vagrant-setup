# PostgreSQL recipe

This cookbook will serve as a starting point for a PostgreSQL 8.4.8 installation
Supported systems: *Ubuntu Linux Lucid 64bits.*

## Connect

- host: 33.33.33.10
- user: postgres:p0stgres
- port: 5432

## Warning

*Disclaimer:* This recipe should never be used on production environments as
it's insecure on purpose.