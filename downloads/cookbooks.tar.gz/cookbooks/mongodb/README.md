# MongoDB recipe

This cookbook will install and start MongoDB.
Supported systems: *Ubuntu Linux Lucid 64bits.*

## Connect

- host: 33.33.33.10
- port: 27017 (db)
- port: 28017 (web admin)

## Warning

*Disclaimer:* This recipe should never be used on production environments as
it's insecure on purpose.