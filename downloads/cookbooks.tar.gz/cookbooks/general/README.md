# General recipes

Cookbook to put general configurations for all boxes. Like a customized
profile or some UNIX packages like htop.

## Warning

*Disclaimer:* This recipe should never be used on production environments as
it's insecure on purpose.